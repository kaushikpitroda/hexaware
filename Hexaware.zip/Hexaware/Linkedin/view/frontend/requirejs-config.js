var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Hexaware_Linkedin/js/model/shipping-save-processor/default'
        }
    }
};