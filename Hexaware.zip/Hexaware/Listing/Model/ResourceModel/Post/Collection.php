<?php
namespace Hexaware\Listing\Model\ResourceModel\Post;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'post_id';
	protected $_eventPrefix = 'hexaware_listing_post';
	protected $_eventObject = 'post_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Hexaware\Listing\Model\Post', 'Hexaware\Listing\Model\ResourceModel\Post');
	}

}

